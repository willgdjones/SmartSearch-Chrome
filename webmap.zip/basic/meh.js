//localStorage.clear();
/*for(i = 0; i < 10; i++) {
	localStorage["idsdfg" + i] = "http://dfljngasn gkajrgn kbkddfgdf " + i;
}*/

var output = "";
for (var x = 0; x < localStorage.length; x++){
    output = output + localStorage.key(x) + " : " + localStorage.getItem(localStorage.key(x)) + "<br />";
}

//document.getElementById("currentLink").innerHTML = "" + output;